<?php
  /*
  Plugin Name: RHUB Page settings.
  Description: Page Settings for SaveTheChildren Resource hub Website.
  Version: 1.0.0
  Author: Save The Children
  Author URI: https://www.savethechildren.org.uk
  Contributors: Fabrizio Del Tufo
  Plugin URI: https://github.com/fabriziodeltufo
  License: GPLv2 or later
  License URI:  https://www.gnu.org/licenses/gpl-2.0.html
  Text Domain: rhubpage
  Domain Path:  /languages
  */

  // If this file is called directly, abort.
  if ( ! defined( 'WPINC' ) ) {
    die;
  }

  define( 'WPPLUGIN_URL', plugin_dir_url( __FILE__ ) );
  define( 'WPPLUGIN_DIR', plugin_dir_path( __FILE__ ) );


  include( plugin_dir_path( __FILE__ ) . 'includes/rhubpage-style.php');

  include( plugin_dir_path( __FILE__ ) . 'includes/rhubpage-settings-fields.php');

  include( plugin_dir_path( __FILE__ ) . 'includes/rhubpage-menu.php');
